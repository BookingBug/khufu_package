exports.handler = (event, context, callback) => {
    // TODO implement


    console.log("Test from Khufu", event, context)

    callback(null, 'Hello from Lambda');


};